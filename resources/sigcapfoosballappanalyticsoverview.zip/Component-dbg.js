sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("sig.cap.foosball.app.analyticsoverview.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);