sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("sig.cap.foosball.app.adminseasons.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);